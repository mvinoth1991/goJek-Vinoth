package MainPages;

import io.restassured.response.ValidatableResponse;
import java.io.*;
import static io.restassured.RestAssured.given;

public class CompareTwoFiles {
    private static String emptyURL ="";
    public static void main(String[] args) {
            BufferedReader reader1 = null,reader2 = null;
            try {
                reader1 = new BufferedReader(new FileReader("src\\main\\resources\\TestFiles\\File1.txt"));
                reader2 = new BufferedReader(new FileReader("src\\main\\resources\\TestFiles\\File2.txt"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        try {
        String line1 = null;
        line1 = reader1.readLine();
        String line2 = null;
        line2 = reader2.readLine();
        boolean areEqual = true;
            int lineNum = 1;
            while (line1 != null || line2 != null) {
                if (line1 == null || line2 == null) {
                    areEqual = false;
                } else if (!line1.equalsIgnoreCase(line2)) {
                    areEqual = false;
                }
                line1 = reader1.readLine();
                line2 = reader2.readLine();
                if(line1.equals(emptyURL) || line2.equals(emptyURL)) {
                    System.out.println("Any one URL from the read file is empty or contains space in line number "+lineNum + " of either file 1 or file 2");
                }else{
                    getApiCall(line1, line2);
                }
                lineNum++;
            }
            } catch (Exception e) {
            }
        try {
            reader1.close();
            reader2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void getApiCall(String url1,String Url2) {
        ValidatableResponse response11 = given().when().get(url1).then();
        ValidatableResponse response22 = given().when().get(Url2).then();
            /*System.out.println("content type:" + response11.extract().contentType());
            System.out.println("content type:" + response22.extract().contentType());*/
            try{
            boolean flag=response11.extract().asString().equals(response22.extract().asString());

            if(flag)
            {
                System.out.println(url1 +" equals " +Url2 );
            }
            else
                System.out.println(url1 +" not equals " +Url2 );}
            catch (Exception e) {
                    e.printStackTrace();
                }
    }
}


